# Crosspoke Fragenbank – v0.1

30 Einträge, 3 je Hauptkategorie. Ziel: mindestens 300 freigegebene Fragen (30 je Kategorie). Noch nicht für den öffentlichen Release geeignet. Antwortwerte sind mit recherchierten Quellen belegt; die redaktionellen Hinweise basieren teils auf gerundeten Vergleichen und sind nicht unabhängig vollständig geprüft oder spielgetestet. EditorialNote enthält Annahmen und Schwachstellen.

## Datenregeln
- IDs bleiben unverändert, auch bei redaktioneller Korrektur. Revision erhöhen; bei vollständig neuer Frage neue ID.
- answerValue ist eine Zahl in der ausdrücklich angezeigten Einheit. Kleinste absolute Abweichung gewinnt. Keine automatische Umrechnung nötig.
- hint1: ungewöhnlicher Vergleich, nicht exakt lösbar. hint2: sachlicher Kontext, sinnvoll eingrenzend. Beide zusammen auf Lösungsleck prüfen. Keine künftigen Hinweise oder Antwort im normalen Spiel-UI vor ihrer Phase anzeigen.
- qualityStatus: draft | source_checked | approved | retired. Nur approved im Release ausspielen. hintReviewStatus und playtestStatus getrennt pflegen.
- source und referenceDate bei Änderungen nachprüfen. Bei Schätzungen Quelle und Bezugsgröße klar benennen.
- Fragenhistorie und Analytics getrennt von Inhaltsdatei speichern (questionId und revision referenzieren), so bleiben neue Fragen ohne Verlust der Historie importierbar.
- Spätere Fragepakete werden nach ID zusammengeführt. Doppelte IDs, leere Felder, unzulässige Kategorien und nicht numerische Antworten ablehnen.

## Prüfung
Struktur geprüft: 30 eindeutige IDs, 10 Kategorien, je 3 Einträge, numerische Antworten, zwei unterschiedliche Hinweise, Quellen-URLs. Keine abschließende redaktionelle Freigabe oder Playtests.

## Redaktionelle Pflege in Notion
- Arbeitsseite: https://app.notion.com/p/424f73ae951f81248732f99ce212e6a6?pvs=204
- Jede abgestimmte Ergänzung oder Korrektur zuerst in Notion und anschließend im versionierten JSON-/ZIP-Paket nachvollziehen. IDs, Frage, Antwort, Hinweise, Quellen und Prüfstatus abgleichen. Keine automatische Synchronisierung.
- Notion zeigt den redaktionellen Kernbestand; technische Metadaten und Detailnotizen bleiben im JSON.
