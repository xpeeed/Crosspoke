# Crosspoke – Fragenbank v0.2

- 30 Fragen, 3 pro Hauptkategorie; Ziel mindestens 300.
- Schema 1.1, Datenversion 0.2, Revision 2 für alle 30 Fragen.
- `hint2` enthält den neuen aktiven Hinweis; `hint2Previous` bewahrt die ursprüngliche Fassung. Nur `hint1` und `hint2` im Spiel anzeigen. Historischer Hinweis ist optional für künftig erstmals erstellte Fragen.
- Fragen, erste Hinweise, Antwortwerte, Einheiten, Quellen und IDs wurden beibehalten.
- Neue Hinweise verwenden konkrete Zahlen, bekannte Bezugsgrößen oder grobe, redaktionell abgeleitete Schätzintervalle; Intervalle sind keine separat erhobenen Messwerte.
- Neue Hinweisformulierungen sind nicht vollständig unabhängig quellengeprüft oder spielgetestet. `qualityStatus=source_checked` bezieht sich auf die zuvor geprüften Antwortwerte. `hintReviewStatus=pending`, `playtestStatus=pending`, `releaseReady=false`.
- Zusätzliche Quellen für ausgewählte neue Hinweise: Nintendo https://www.nintendo.co.jp/ir/en/finance/hard_soft/index.html ; Golden Gate Bridge https://www.goldengate.org/bridge/history-research/statistics-data/design-construction-stats/ ; NASA https://www.nasa.gov/missions/apollo/apollo-11/apollo-11-mission-overview/ ; US Mint https://www.usmint.gov/news/media-kit/penny .

## Notion-Pflege

Redaktionelle Übersicht: https://app.notion.com/p/424f73ae951f81248732f99ce212e6a6
Native Datenbank: https://app.notion.com/p/424f73ae951f81efab83fcc7c8c0df38
Ansichten: Alle Fragen, Nach Kategorie, Hinweisvergleich, Prüfung offen, Freigegeben.

Bei Änderungen zuerst Notion aktualisieren, dann das versionierte JSON/ZIP abgleichen. IDs beibehalten. Keine automatische Synchronisation. Historische Hinweise bei Überarbeitung erhalten. Keine Veröffentlichung vor Freigabe. Technische Metadaten bleiben im JSON.

## Dateien

- crosspoke-fragen-v0.2.json: Inhaltsdaten.
- questions.schema.json: JSON Schema Draft 2020-12.
- README.md: Pflege und Status.

Validiert: JSON-Schema, 30 eindeutige IDs, 3 Fragen je Kategorie, alle 30 ursprünglichen Hinweise 2 erhalten, 30 neue Hinweise, unveränderte Kernfelder. Kein Mac-Projektordner geändert.
