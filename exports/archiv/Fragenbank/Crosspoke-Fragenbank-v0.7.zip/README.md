# Crosspoke – Fragenbank v0.4

30 Fragen, 3 pro Hauptkategorie; Ziel mindestens 300. Schema 1.2, Datenversion 0.4, Revision 3–4. Release noch nicht freigegeben.

## Redaktioneller Standard
Hinweis 1: ungewöhnlicher Größenvergleich. Hinweis 2: konkrete, allgemein verständliche quantitative Fakten oder bekannte Referenzwerte; eine hilfreiche Information genügt. Grobes Rechnen und eigene Interpretation erlaubt, zu genaue Berechnung auch in Kombination vermeiden. Reine Antwortintervalle nur ausnahmsweise. Geeignete alte Hinweise können beibehalten werden. Alle 30 Hinweispaare redaktionell bewertet; 29 aktive Hinweise verändert, einer beibehalten. Neue Fakten und beide Hinweise sind noch nicht vollständig unabhängig quellengeprüft und nicht spielgetestet. `qualityStatus=source_checked` bezieht sich auf die bereits geprüften Antwortwerte; `hintReviewStatus=pending`, `playtestStatus=pending`, `releaseReady=false`.

## Historie
`hint2` = aktiv; `hint2Previous` = ursprünglicher Hinweis v0.1; `hint2V02` = archivierter Hinweis v0.2. Ausschließlich `hint1` und `hint2` im Spiel ausgeben. Quellen, IDs und Hinweise unverändert; Frageformulierung und Antwortmaßstab in v0.4 teilweise geändert. Absolute Antwortwerte bleiben identisch. Zusätzliche Referenzen zu ausgewählten neuen Fakten in `editorialNote`.

## Notion-Pflege
Übersicht: https://app.notion.com/p/424f73ae951f81248732f99ce212e6a6
Datenbank: https://app.notion.com/p/424f73ae951f81efab83fcc7c8c0df38
Ansichten: Alle Fragen, Nach Kategorie, Hinweisvergleich, Prüfung offen, Freigegeben. Spalten: Frage, Hinweis 1, Hinweis 2, Antwortwert, Einheit, Fragen-ID, Kategorie, Unterkategorie, Quelle, Qualitätsstatus. Historische Hinweise und Prüfmetadaten zusätzlich in Hinweisvergleich.
Notion zuerst aktualisieren, dann das versionierte Datenpaket abgleichen. Keine automatische Synchronisierung. Kein Mac-Projektordner geändert.

## Dateien
- crosspoke-fragen-v0.6.json
- questions.schema.json (JSON Schema Draft 2020-12)
- README.md

Validiert: Schema, 30 eindeutige IDs, 3 Fragen pro Kategorie, beide historischen Fassungen, unveränderte IDs, Hinweise, Quellen und absolute Antwortwerte.

## Antwortformat (v0.4)
Alle 30 Fragen auf eindeutige Einheit und geeigneten Maßstab geprüft. 13 Formulierungen geändert, davon fünf Einheiten umgerechnet (Tsd. Teile, Tsd. Enten, Tsd. km, t und km). Alle übrigen 17 bereits eindeutig. Dezimalwerte zulassen, keine ganzzahlige Tausender-Rundung erzwingen. UI zeigt die Einheit aus `unit` bereits ab der Frage deutlich und bei der Antwort erneut; `answerValue` ist immer in dieser Einheit gespeichert. Vorherige Werte und Formulierungen bei geänderten Fragen in `editorialNote`. Die Maßstabwahl dient der Orientierung und Handhabung; keine festen Grenzen für Schätzwerte außer fachlich erforderlichen (z. B. Prozent 0–100). Keine neue Quellenprüfung oder Freigabe.


## v0.5 – Kurzfragen und optionale Erklärungen

Datensatz 0.5, Schema 1.3. Alle 30 Fragen redaktionell bearbeitet; 28 optionale Fragekontexte, 30 Antworterklärungen. Notion-Ansicht „Frage & Erklärung“: https://app.notion.com/p/424f73ae951f81efab83fcc7c8c0df38?v=424f73ae951f81d1b8ee000c2c509f4d. Die ursprüngliche Hauptansicht und deren Spaltenfolge bleiben unverändert. Antwortwerte, Einheiten, Hinweise und Quellen bleiben unverändert.

UX-Entwurf (noch nicht implementiert): Einheit immer direkt unter der Frage anzeigen, auch bei kurzen Fragen ohne ausgeschriebene Einheit. Fragekontext vor dem Notieren der Schätzungen auf gemeinsamen Bildschirm aufklappbar, keine zusätzliche Zahlenhilfe; bei null ausblenden. Antworterklärung erst nach Antwortfreigabe aufklappbar; Link aus source nach der Auflösung zugänglich. Keine zusätzlichen Spielphasen oder Pflichtklicks. Wichtige Abgrenzung muss bereits in Frage und Einheit eindeutig sein. Kontext und Erläuterung redaktionelle Entwürfe; Quellenprüfung und Playtest weiterhin offen.

## v0.6 – Gummientenfrage

CUR-0001: Hinweis 1 durch realen, überraschenden Hochschulvergleich ersetzt. Alte Fassung und Destatis-Zusatzquellen in editorialNote erhalten. Antworterklärung ergänzt, Revision 6. Übrige Fragen unverändert; keine Endfreigabe. Reale überraschende Quervergleiche bevorzugen, rein hypothetische triviale Vergleiche vermeiden.


## v0.7 – Prototyp-Fragenbestand eingefroren
30 Fragen redaktionell überprüft, 15 erste Hinweise gegenüber v0.6 ersetzt, 15 beibehalten. Alte Hinweise in hint1V06 (sofern geändert), zusätzlich alle 30 Antworterklärungen erweitert; zusätzliche Referenzen in additionalSources, Review-Begründung in hintReviewNote. TEC-0003: historische Zeichenangabe statt MB; früherer Wortlaut archiviert. Antworterklärung und Quellen erst nach Auflösung freiwillig aufklappbar. Fragekontext optional vor Schätzung, keine zusätzlichen Lösungshinweise. Alle 30 als Prototypmaterial; vollständige Faktenprüfung und Freigabe vor Veröffentlichung ausstehend. M4.1 vorerst beendet, 270 weitere Fragen zurückgestellt.
