# Crosspoke – Fragenbank v0.3

30 Fragen, 3 pro Hauptkategorie; Ziel mindestens 300. Schema 1.2, Datenversion 0.3, Revision 3. Release noch nicht freigegeben.

## Redaktioneller Standard
Hinweis 1: ungewöhnlicher Größenvergleich. Hinweis 2: konkrete, allgemein verständliche quantitative Fakten oder bekannte Referenzwerte; eine hilfreiche Information genügt. Grobes Rechnen und eigene Interpretation erlaubt, zu genaue Berechnung auch in Kombination vermeiden. Reine Antwortintervalle nur ausnahmsweise. Geeignete alte Hinweise können beibehalten werden. Alle 30 Hinweispaare redaktionell bewertet; 29 aktive Hinweise verändert, einer beibehalten. Neue Fakten und beide Hinweise sind noch nicht vollständig unabhängig quellengeprüft und nicht spielgetestet. `qualityStatus=source_checked` bezieht sich auf die bereits geprüften Antwortwerte; `hintReviewStatus=pending`, `playtestStatus=pending`, `releaseReady=false`.

## Historie
`hint2` = aktiv; `hint2Previous` = ursprünglicher Hinweis v0.1; `hint2V02` = archivierter Hinweis v0.2. Ausschließlich `hint1` und `hint2` im Spiel ausgeben. Quellen, IDs, Fragen, Antwortwerte, Einheiten und Hinweis 1 unverändert. Zusätzliche Referenzen zu ausgewählten neuen Fakten in `editorialNote`.

## Notion-Pflege
Übersicht: https://app.notion.com/p/424f73ae951f81248732f99ce212e6a6
Datenbank: https://app.notion.com/p/424f73ae951f81efab83fcc7c8c0df38
Ansichten: Alle Fragen, Nach Kategorie, Hinweisvergleich, Prüfung offen, Freigegeben. Spalten: Frage, Hinweis 1, Hinweis 2, Antwortwert, Einheit, Fragen-ID, Kategorie, Unterkategorie, Quelle, Qualitätsstatus. Historische Hinweise und Prüfmetadaten zusätzlich in Hinweisvergleich.
Notion zuerst aktualisieren, dann das versionierte Datenpaket abgleichen. Keine automatische Synchronisierung. Kein Mac-Projektordner geändert.

## Dateien
- crosspoke-fragen-v0.3.json
- questions.schema.json (JSON Schema Draft 2020-12)
- README.md

Validiert: Schema, 30 eindeutige IDs, 3 Fragen pro Kategorie, beide historischen Fassungen, unveränderte Kernfelder.
