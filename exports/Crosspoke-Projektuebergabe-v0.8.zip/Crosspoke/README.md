# Crosspoke – Übergabepaket

Stand: 26.11.2026. Aktuelle Web-Testversion v0.2.2; Fragenbestand v0.8, 30 Fragen. Kein Release.

## Auf dem Mac
Entpacke dieses ZIP in denselben übergeordneten Projektordner wie Stichwerk, Quintessence und Arcane Aegis. Es enthält bereits den Ordner `Crosspoke`. Wenn ein gleichnamiger Ordner existiert, erst vergleichen; nicht blind ersetzen. Der tatsächliche Mac-Pfad ist in diesem Chat nicht zugänglich.

## Start
Öffne `04 – Entwicklung/index.html` in Safari/Chrome. Dies ist die bytegenau mit GitHub abgeglichene eigenständige Table-Mode-Testversion. Kein Backend nötig. Falls lokale Dateinavigation im Browser blockiert wird, aus diesem Verzeichnis einen lokalen HTTP-Server starten (z. B. `python3 -m http.server 4173`) und http://127.0.0.1:4173 öffnen.

Die alte vollständige Core/Web-Implementierung liegt getrennt unter `04 – Entwicklung/Altes Core-Web-Paket v0.2.0/` und zusätzlich als Original-ZIP im Archiv. Sie enthält den alten Fragenbestand v0.7 und darf nicht als aktueller Spielstand behandelt werden. Die Änderungen der Standalone-Testversion wurden noch nicht in die vollständige Core/Web-Implementierung integriert.

## Daten und Veröffentlichungen
- Redaktioneller Master: Notion.
- Technischer Master: GitHub main, `index.html` und `questions-v0.8.json`.
- Sites soll zukünftig Testumgebung sein; es wurde noch keine Crosspoke-Site veröffentlicht. Kein Sites-Link vorhanden.
- Render wird nicht mehr aktiv synchronisiert; vorhandene GitHub-Auto-Deploy-Einstellung nicht geändert.
- Notion-Dokumentation in diesem Paket ist eine konsolidierte, quellenbasierte Zusammenfassung, kein vollständiger Notion-Export. Für Originalseiten und Datenbankhistorie die Links in `06 – Dokumentation/Notion-Quellen.md` benutzen.

Siehe HANDOVER.md, Inventar und Testprotokoll. Antworten sind absichtlich in der lokalen Testdatei enthalten; keine Anti-Cheat-Garantie.
