# Handover – Crosspoke

Aktueller GitHub-Stand: https://github.com/xpeeed/Crosspoke (main). Die im Paket enthaltenen aktuellen HTML- und JSON-Dateien stimmen bytegenau mit den entsprechenden GitHub-Blobs überein. Notion-Quellen und Entscheidungshistorie unter `06 – Dokumentation`.

## Nächste Schritte
1. Ordner Crosspoke auf dem Mac in den gemeinsamen Gamification-Projektordner übernehmen; vorhandenen Ordner vorher vergleichen. Dieses ZIP wurde nicht auf den Mac kopiert.
2. Sites-Funktion nutzen, um `04 – Entwicklung/index.html` als separate Crosspoke-Testseite zu veröffentlichen. Tatsächlichen Link und Spielstart prüfen, anschließend in Notion und Projekt-Doku hinterlegen. Kein Render-Deployment auslösen. Ohne Sites-Funktion keinen Link erfinden.
3. Vollständigen Original-Notion-Export mit Unterseiten und Markdown/CSV im Dokumentationsordner ergänzen.
4. Änderungen v0.2.2/v0.8 in das vollständige Core/Web-Paket integrieren, nicht das historische Paket als aktuellen Build deklarieren. Browser-, Geräte- und Persistenztests; M4.5 Dashboard danach.
5. Bei jeder künftigen Änderung zuerst Notion (redaktionell) und dann GitHub (technisch) abgleichen, Versionshistorie pflegen, anschließend Sites aktualisieren und verifizieren. Keine Veröffentlichung unfertiger Fragen als Release.

## Abgrenzung
Die 30 Fragen haben noch keine vollständige unabhängige Endfreigabe. Die frühere v0.2.0 Core-Web-Architektur besitzt Funktionen, die im aktuellen Standalone nicht vollständig erhalten sind. Die exportierte CSV ist nur eine Übersicht der aktuellen technischen JSON, kein Original-Notion-Datenbankexport. Keine Mac- oder Sites-Aktion wurde in diesem Chat durchgeführt. Render-Auto-Deploy wurde nicht geändert. Keine anderen Projekte bearbeitet.
